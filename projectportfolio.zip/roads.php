<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Marlum Nigeria LTD:</title>
<link href="css/css_plugin.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/ddcolortabs.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/gooeymenu.css"   media="screen" rel="stylesheet" type="text/css"/>
<link rel="icon" href="images/icon.png" type="image/png" />
<link rel="shortcut icon" href="images/icon.png" type="image/png" />

<script type="text/javascript" src="script/jquery-1.9.1.js"></script>
<script type="text/javascript" src="script/dropdowntabs.js"></script>
<script type="text/javascript" src="script/gooeymenu.js"></script>

<!--animation-->

<link type="text/css" href="css/style.css" rel="stylesheet" media="screen" />
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<!--end of anim -->
</head>
<body>
<div align="center">
<table height="20">
<tr>
<td>
</td>
</tr>
</table>
<table width="1000" align="center"  class="bannerwrapper">
<tr>
<td width="15">
</td>
<td style="background-image:url(images/logo.png);
background-position:left;
background-repeat:no-repeat
">
</td>
<td colspan="3">
</td>
</tr>
</table>





<table width="1000" class="wrapper" align="center"  >
<tr >
<td colspan="5">
<div id="navigation">
<ul id="gooeymenu2" class="solidblockmenu">
<li><a href="index.php" id="register">|&nbsp;&nbsp;&nbsp;HOME&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="aboutus.php" rel="dropmenu1">|&nbsp;&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="projectportfolio.php" rel="dropmenu2">|&nbsp;&nbsp;&nbspPROJECT PORTFOLIO&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="investorrelation.php" rel="dropmenu3">|&nbsp;&nbsp;&nbsp;INVESTOR RELATION&nbsp;&nbsp;&nbsp;|</a></li>
<!--<li><a href="#" id="report" rel="dropmenu4">|&nbsp;&nbsp;&nbsp;CAREER&nbsp;&nbsp;&nbsp;|</a></li>-->
<li><a href="contactus.php">|&nbsp;&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;|</a><li>
</ul>
</div>
<div id="dropmenu1" class="dropmenudiv_a">
                 <a href="ourprofile.php" id="male">Our Profile</a>
                    <a href="ourvalues.php" id="female">Our Values</a>
                     <a href="ourhistory.php" id="nd1">Our History</a>
                        <a href="ourgroup.php"  id="nd2">Our Group</a>
                      
                    </div>
					<div id="dropmenu2" class="dropmenudiv_a">
                 <a href="infrastructure.php" id="male">Infrastructure</a>
                    <a href="buildings.php" id="female">Buildings</a>
					 <a href="roads.php" id="female">Roads</a>
                     <a href="industries.php" id="nd1">Industries</a>
                        <a href="facilities.php"  id="nd2">Facility Services</a>
                    </div>
<div id="dropmenu3" class="dropmenudiv_a">
                 <a href="boardofdirectors.php" id="male">Board Of Directors</a>
              <!--  <a href="cooperategovernance.php" id="female">Co-Operate Governance</a> -->
                 <!--  <a href="businessprinciple.php" id="nd1">Business Principles</a> -->
				 
		
		
		<a href="businessdevelopment.php"  id="nd2">Business Development</a>
                      <!--    <a href="financialreporting.php" id="ndyr1">Financial Reporting</a> -->
                    </div>
					<div id="dropmenu4" class="dropmenudiv_a">
<!--
                 <a href="cooperateculture" id="male">Corperate Culture</a>
                    <a href="marlumexperience.php" id="female">Marlum Experiances</a>
    -->
	                 <a href="" id="nd1" onclick="alert('Job Vacancy Not Available')">Apply Online</a>
                    <!--application.php-->
					</div>

   <script>
                tabdropdown.init("navigation", 0)
                gooeymenu.setup({id:"gooeymenu2", selectitem:-3, fx:"swing"})
                </script>  
               
</td>
</tr>
</table>



<table class="pixwrapper" style="" cellpadding="0" cellspacing="0">
<tr>
<!--style="background:url(images/logoback.png);"-->
<td  valign="top" style="
width:960px;
border:1px solid #b52025; background-image:url(images/road.png); background-repeat:no-repeat; background-position:center;">

</td>
</tr>
</table>
<table>
<tr>
<td class="contentwrapper">
<table width="100%" cellpadding="0" cellspacing="0" >
<tr>
<td colspan="2" style="height:10px"></td>
</tr>
<tr style="height:35px; ">
<td width="60%" style="color:#999999; font-size:28px; font-style:inherit; font-family:Calibre; font-weight:500; padding-left:20px">Roads</td>
<td width="40%" style="background:url(images/menu.png); padding-left:10px; color:#FFFFFF">|ROADS|</td>
</tr>
<tr style="height:275px;">

<td colspan="2" valign="top" style="color:#666666; font-size:15px; font-style:inherit; font-family:Calibre; font-weight:50; padding-left:40px; padding-top:10px; padding-right:25px">
<table width=100% border="0">
<tr>
<td width="65%" valign="top">
 <b>Marlum Nigeria limited </b>
 <br /> 
<b> Highway Construction </b>
Marlum Nigeria limited has been involved in the construction of so many major roads in Akwa-Ibom, Anambra,Delta,Lagos,Ebonyi and Enugu States.Among those Roads include the construction of Chime Avenue Dual Carriageway EBEANO TUNNEL CROSSING.
<br />
<b>Bridges Construction </b>
construction of six(6) Bridges along Abakaliki Aferekpe Road and so many other bridges accross the states :
<br />
<b>
Airport</b>
MARLUM Nigeria Limited constructed all the TERMINAL ROADS in the AKWA IBOM INTERNATIONAL AIRPORT Uyo for the State Government, and has done a lot of rehabilitation work at AKANU IBIAM AIRPORT ENUGU. 
</td>

</td>
<td width="35%" valign="top" style="padding-left:25px">
<b>Social Media</b><br />	
                            <table width="100%" align="center" border="0">
                            <tr>
                            <td align="left">
                                            <ul class="social-icons">
                        <li><a href="https://www.facebook.com/marlumnigeria" target="_blank"><img src="images/facebook.png" alt="Find Us On Facebook" /></a></li>
                    </ul>
</td>
               </tr>
			   </table>

<br />
------------------------------------------------------
<br />

<b>Our Gallery</b>
<br />
<a href="gallery.php"><div align="center" style="cursor:pointer; background-image:url(images/gallery22.png); background-repeat:no-repeat; height:80px; width:164px"></div></a>
------------------------------------------------------
<b>Document</b>
<br />
<label onclick="window.print()" style="cursor:pointer;">Print Page</label>
<br />
------------------------------------------------------
<!--Put the share Link Here.       and also allow printing of page.-->
</td>
</tr>
</table>

</td>
</tr>
</table></td>

</tr>
</table></td>

</tr>
</table>
<br />
<table class="footer">
<tr>
<td align="left">
&nbsp;&nbsp;&nbsp;&nbsp;© 2013 - Marlum Nigeria LTD
</td>
<td>

</td>
<td align="right">
Developer: Libra Information Technology(Gensoft-Software)&nbsp;&nbsp;&nbsp;&nbsp;
</td>
</tr>
</table>

</body>
</html>
