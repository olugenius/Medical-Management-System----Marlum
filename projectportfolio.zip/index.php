<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Marlum Nigeria LTD:: Home Page</title>
<link href="css/css_plugin.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/ddcolortabs.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/gooeymenu.css"   media="screen" rel="stylesheet" type="text/css"/>
<link rel="icon" href="images/icon.png" type="image/png" />
<link rel="shortcut icon" href="images/icon.png" type="image/png" />


<script type="text/javascript" src="script/jquery-1.9.1.js"></script>
<script type="text/javascript" src="script/dropdowntabs.js"></script>
<script type="text/javascript" src="script/gooeymenu.js"></script>

<!--animation-->
<link type="text/css" href="css/style.css" rel="stylesheet" media="screen" />
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<!--end of anim -->
<!--facebook-->
<!--<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js' type='text/javascript'/>-->
</head>
<body>
<!--Floating Facebook Widget by www.TheBlogWidgets.com START-->
<script type="text/javascript"> /*<![CDATA[*/ jQuery(document).ready(function() {jQuery(".marlumnigeria").hover(function() {jQuery(this).stop().animate({right: "0"}, "medium");}, function() {jQuery(this).stop().animate({right: "-250"}, "medium");}, 500);}); /*]]>*/ </script> <style type="text/css"> .marlumnigeria{background: url("http://3.bp.blogspot.com/-TaZRLv66f8g/UoMnTyTbF6I/AAAAAAAAAGY/U4qcf-SP6d0/TheBlogWidgets_facebook_widget.png") no-repeat scroll left center transparent !important; float: right;height: 270px;padding: 0 5px 0 46px;width: 245px;z-index:  99999;position:fixed;right:-250px;top:20%;} .marlumnigeria div{ padding: 0; margin-right:-8px; border:4px solid  #3b5998; background:#fafafa;} .marlumnigeria span{bottom: 4px;font: 8px "lucida grande",tahoma,verdana,arial,sans-serif;position: absolute;right: 6px;text-align: right;z-index: 99999;} .marlumnigeria span a{color: gray;text-decoration:none;} .marlumnigeria span a:hover{text-decoration:underline;} } </style><!--Brought to you by www.TheBlogWidgets.com--><div class="marlumnigeria" style="">
<!--Brought to you by http://www.marlumnigeria.com/2013/11/floating-facebook-like-box-widget-for.html--><div>
<!-- http://www.marlumnigeria.com/2013/11/floating-facebook-like-box-widget-for.html--> <iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Ffacebook.com%2Fmarlumnigeria&width=245&colorscheme=light&show_faces=true&border_color=white&connections=9&stream=false&header=false&height=270" scrolling="no" frameborder="0" scrolling="no" style="border: white; overflow: hidden; height: 270px; width: 245px;background:#fafafa;color:000;"><!--Brought to you by www.TheBlogWidgets.com--></iframe><!--Brought to you by www.TheBlogWidgets.com--><span><!--Brought to you by www.TheBlogWidgets.com--></span></div>
</div>
<!--Floating Facebook Widget by www.TheBlogWidgets.com END-->

<div align="center">
<table height="20">
<tr>
<td>
</td>
</tr>
</table>
<table width="1000" align="center"  class="bannerwrapper">
<tr>
<td width="15">
</td>
<td style="background-image:url(images/logo.png);
background-position:left;
background-repeat:no-repeat
">
</td>
<td colspan="2">
</td>
<td width="76">
<a href=" http://webmail.marlumnigeria.org"><img src="images/webmail.png" /></a>
</td>
</tr>
</table>

<table width="1000" class="wrapper" align="center"  >
<tr >
<td colspan="5">
<div id="navigation">
<ul id="gooeymenu2" class="solidblockmenu">
<li><a href="index.php" id="register">|&nbsp;&nbsp;&nbsp;HOME&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="aboutus.php" rel="dropmenu1">|&nbsp;&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="projectportfolio.php" rel="dropmenu2">|&nbsp;&nbsp;&nbspPROJECT PORTFOLIO&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="investorrelation.php" rel="dropmenu3">|&nbsp;&nbsp;&nbsp;INVESTOR RELATION&nbsp;&nbsp;&nbsp;|</a></li>
<!--<li><a href="#" id="report" rel="dropmenu4">|&nbsp;&nbsp;&nbsp;CAREER&nbsp;&nbsp;&nbsp;|</a></li>-->
<li><a href="contactus.php">|&nbsp;&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;|</a><li>
</ul>
</div>
<div id="dropmenu1" class="dropmenudiv_a">
                 <a href="ourprofile.php" id="male">Our Profile</a>
                    <a href="ourvalues.php" id="female">Our Values</a>
                     <a href="ourhistory.php" id="nd1">Our History</a>
                        <a href="ourgroup.php"  id="nd2">Our Group</a>
                      
                    </div>
					<div id="dropmenu2" class="dropmenudiv_a">
                 <a href="infrastructure.php" id="male">Infrastructure</a>
                    <a href="buildings.php" id="female">Buildings</a>
					 <a href="roads.php" id="female">Roads</a>
                     <a href="industries.php" id="nd1">Industries</a>
                        <a href="facilities.php"  id="nd2">Facility Services</a>
                    </div>
<div id="dropmenu3" class="dropmenudiv_a">
                 <a href="boardofdirectors.php" id="male">Board Of Directors</a>
              <!--  <a href="cooperategovernance.php" id="female">Co-Operate Governance</a> -->
                 <!--  <a href="businessprinciple.php" id="nd1">Business Principles</a> -->
				 
		
		
		<a href="businessdevelopment.php"  id="nd2">Business Development</a>
                      <!--    <a href="financialreporting.php" id="ndyr1">Financial Reporting</a> -->
                    </div>
					<div id="dropmenu4" class="dropmenudiv_a">
<!--
                 <a href="cooperateculture" id="male">Corperate Culture</a>
                    <a href="marlumexperience.php" id="female">Marlum Experiances</a>
    -->
	                 <a href="" id="nd1" onclick="alert('Job Vacancy Not Available')">Apply Online</a>
                    <!--application.php-->
					</div>

   <script>
                tabdropdown.init("navigation", 0)
                gooeymenu.setup({id:"gooeymenu2", selectitem:-5, fx:"swing"})
                </script>  
               
</td>
</tr>
</table>
<table class="pixwrapper" style="" cellpadding="0" cellspacing="0">
<tr>
<!--style="background:url(images/logoback.png);"-->
<td  valign="top">

<div style="width:958px; height:298px; ">

    <div class="slide-box mod-con">

      <ul class="slide-player">

<li><a href="#"><img src="images/slide2.png" alt="" style="width:958px; height:298px; border:1px solid #b52025; "/></a></li>
        <li><a href="#"><img src="images/slide3.png" alt=""  style="width:958px; height:298px; border:1px solid #b52025; "/> </a></li>
        <li><a href="#"><img src="images/slide4.png" alt=""  style="width:958px; height:298px; border:1px solid #b52025; "/></a></li>
	  	<li><a href="#"><img src="images/slide1.png" alt=""  style="width:958px; height:298px; border:1px solid #b52025; "/></a></li>
        <li class="selected"><a href="#"><img src="images/slide1.png" alt="" style="width:958px; height:298px; border:1px solid #b52025;"/></a></li>
        


</ul>
      <div class="slide-menu"></div>

	</div>

	</div>
</td>
</tr>
</table>
<br />
<br />
<table>
<tr>
<td class="homecontentwrapper">
<table width="100%" cellpadding="0" cellspacing="0" >
<tr>
<td colspan="2" style="height:10px">
</td>
</tr>
<tr style="height:35px; ">
<td width="60%" style="color:#999999; font-size:28px; font-style:inherit; font-family:Calibre; font-weight:500; padding-left:20px">Our News
</td>
<td width="40%" style="background:url(images/menu.png); padding-left:10px; color:#FFFFFF">|PRESS RELEASES|
</td>
</tr>
<tr style="height:195px;">
<td colspan="2" valign="top">
<div style="height:185px; width:454px; padding-left:15px" >
  <div class="home_news">
                <?php
				/*
                $query="SELECT * FROM latestnews Order By id Desc";
				
								$rs=mysql_query($query);
											$num=mysql_num_rows($rs);
														if($num>0){

														for($i=0;$i<$num;$i++){
																$row=mysql_fetch_row($rs);
				
					echo "<a>".$row[1]."</a>";
*/
echo "<a>Marlum Webiste Is New.</a>";
echo "<a>Marlum Nigeria Limited is categorized as one the most developing construction company in nigeria.</a>";
/*

															}


														}
*/
									?>
				
				</div>

                

</div>
</td>
</tr>

</table>

</td>
<td style="width:8px">
</td>
<td class="homecontentwrapper">
<table width="100%" cellpadding="0" cellspacing="0" >
<tr>
<td colspan="2" style="height:10px">
</td>
</tr>
<tr style="height:35px; ">
<td width="60%" style="color:#999999; font-size:28px; font-style:inherit; font-family:Calibre; font-weight:500; padding-left:20px">Our Gallery
</td>
<td width="40%" style="background:url(images/menu.png); padding-left:10px; color:#FFFFFF">|CHECK OUR GALLERY|
</td>
</tr>
<tr style="height:195px; background:url(images/gallery.png); background-repeat:no-repeat; background-position:center; cursor:pointer" onclick="window.location='gallery.php'">
<td colspan="2">
</td>
</tr>

</table>



</td>

</tr>
</table>
<br />
<table class="footer">
<tr>
<td align="left">
&nbsp;&nbsp;&nbsp;&nbsp;© 2013 - Marlum Nigeria LTD
</td>
<td>

</td>
<td align="right">
Developer: Libra Information Technology(Gensoft-Software)&nbsp;&nbsp;&nbsp;&nbsp;
</td>
</tr>
</table>
<!--
<tr>
<td colspan="5">
<table width="950" align="left" style="margin-top:5pt;" id="fnt9" >
<tr height="300" valign="top">
<td>
aa
</td>
</tr>
</table>
</td>
</tr>
</table>
<br />
<table>
<tr>
<td colspan="5">

<table height="200" bgcolor="#FFFFFF" width="950" class="wrapper">
<tr style="border:#FF0000 solid thick">
<td colspan="5">
</td>
</tr>
</table>
</td>
</tr>
</table>

<div>
<p  id="footer_txt">All right</p>
</div>
-->
</body>
</html>
