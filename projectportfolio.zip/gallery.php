
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Marlum Nigeria Limited:: Project</title>


<link href="css/css_plugin.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/ddcolortabs.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/gooeymenu.css"   media="screen" rel="stylesheet" type="text/css"/>
<link rel="icon" href="images/icon.png" type="image/png" />
<link rel="shortcut icon" href="images/icon.png" type="image/png" />

<script type="text/javascript" src="script/jquery-1.9.1.js"></script>
<script type="text/javascript" src="script/dropdowntabs.js"></script>
<script type="text/javascript" src="script/gooeymenu.js"></script>

<!--animation-->

<link type="text/css" href="css/style.css" rel="stylesheet" media="screen" />
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>


<script type="text/javascript" src="js/jquery.core.js"></script>
<script type="text/javascript" src="js/jquery.superfish.js"></script>
<script type="text/javascript" src="js/jquery.jcarousel.pack.js"></script>
<script type="text/javascript" src="js/jquery.easing.js"></script>
<script type="text/javascript" src="js/jquery.scripts.js"></script>
    
    

 <!-- stylesheets -->
  <link href="css/style2.css" rel="stylesheet" type="text/css" />

  <link href="css/portfolio_two.css" rel="stylesheet" type="text/css" />
  <link href="css/light.css" rel="stylesheet" type="text/css" />
  <!-- we only want the thunbnails to display when javascript is disabled -->
  <script type="text/javascript">
    document.write('<style>.noscript { display: none; }</style>');
  </script>
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="jqueryslider/js/modernizr-1.5.min.js"></script>



</head>

<body style="background-image:url(images/bg.gif);">

<div align="center">
<table height="20">
<tr>
<td>
</td>
</tr>
</table>
<table width="1000" align="center"  class="bannerwrapper">
<tr>
<td width="15">
</td>
<td style="background-image:url(images/logo.png);
background-position:left;
background-repeat:no-repeat
">
</td>
<td colspan="3">
</td>
</tr>
</table>


<table width="1000" class="wrapper" align="center"  >
<tr >
<td colspan="5">
<div id="navigation">
<ul id="gooeymenu2" class="solidblockmenu">
<li><a href="index.php" id="register">|&nbsp;&nbsp;&nbsp;HOME&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="aboutus.php" rel="dropmenu1">|&nbsp;&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="projectportfolio.php" rel="dropmenu2">|&nbsp;&nbsp;&nbspPROJECT PORTFOLIO&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="investorrelation.php" rel="dropmenu3">|&nbsp;&nbsp;&nbsp;INVESTOR RELATION&nbsp;&nbsp;&nbsp;|</a></li>
<!--<li><a href="#" id="report" rel="dropmenu4">|&nbsp;&nbsp;&nbsp;CAREER&nbsp;&nbsp;&nbsp;|</a></li>-->
<li><a href="contactus.php">|&nbsp;&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;|</a><li>
</ul>
</div>
<div id="dropmenu1" class="dropmenudiv_a">
                 <a href="ourprofile.php" id="male">Our Profile</a>
                    <a href="ourvalues.php" id="female">Our Values</a>
                     <a href="ourhistory.php" id="nd1">Our History</a>
                        <a href="ourgroup.php"  id="nd2">Our Group</a>
                      
                    </div>
					<div id="dropmenu2" class="dropmenudiv_a">
                 <a href="infrastructure.php" id="male">Infrastructure</a>
                    <a href="buildings.php" id="female">Buildings</a>
					 <a href="roads.php" id="female">Roads</a>
                     <a href="industries.php" id="nd1">Industries</a>
                        <a href="facilities.php"  id="nd2">Facility Services</a>
                    </div>
<div id="dropmenu3" class="dropmenudiv_a">
                 <a href="boardofdirectors.php" id="male">Board Of Directors</a>
              <!--  <a href="cooperategovernance.php" id="female">Co-Operate Governance</a> -->
                 <!--  <a href="businessprinciple.php" id="nd1">Business Principles</a> -->
				 
		
		
		<a href="businessdevelopment.php"  id="nd2">Business Development</a>
                      <!--    <a href="financialreporting.php" id="ndyr1">Financial Reporting</a> -->
                    </div>
					<div id="dropmenu4" class="dropmenudiv_a">
<!--
                 <a href="cooperateculture" id="male">Corperate Culture</a>
                    <a href="marlumexperience.php" id="female">Marlum Experiances</a>
    -->
	                 <a href="" id="nd1" onclick="alert('Job Vacancy Not Available')">Apply Online</a>
                    <!--application.php-->
					</div>

   <script>
                tabdropdown.init("navigation", 0)
                gooeymenu.setup({id:"gooeymenu2", selectitem:-2, fx:"swing"})
                </script>  
               
</td>
</tr>
</table>



<table style="" cellpadding="0" cellspacing="0">
<tr>
<!--style="background:url(images/logoback.png);"-->
<td  valign="top" style="
width:958px;
border:1px solid #b52025; background-repeat:no-repeat; background-position:center;">

    <!-- begin content -->
    <div id="site_content">
      <!-- start gallery HTML containers -->
      <div class="navigation-container">
        <div id="thumbs" class="navigation">
          <a class="pageLink prev" style="visibility: hidden;" href="#" title="Previous Page"></a>
          <ul class="thumbs noscript">
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/1.jpg"><img src="jqueryslider/images/portfolio_two/1_thumb.jpg" alt="one" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot; &quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/2.jpg"><img src="jqueryslider/images/portfolio_two/2_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/3.jpg"><img src="jqueryslider/images/portfolio_two/3_thumb.jpg" alt="three" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>

              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/4.jpg"><img src="jqueryslider/images/portfolio_two/4_thumb.jpg" alt="four" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/5.jpg"><img src="jqueryslider/images/portfolio_two/5_thumb.jpg" alt="five" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/6.jpg"><img src="jqueryslider/images/portfolio_two/6_thumb.jpg" alt="six" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/7.jpg"><img src="jqueryslider/images/portfolio_two/7_thumb.jpg" alt="seven" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/8.jpg"><img src="jqueryslider/images/portfolio_two/8_thumb.jpg" alt="eight" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/9.jpg"><img src="jqueryslider/images/portfolio_two/9_thumb.jpg" alt="nine" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/10.jpg"><img src="jqueryslider/images/portfolio_two/10_thumb.jpg" alt="ten" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/10.jpg"><img src="jqueryslider/images/portfolio_two/10_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/11.jpg"><img src="jqueryslider/images/portfolio_two/11_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/12.jpg"><img src="jqueryslider/images/portfolio_two/12_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/13.jpg"><img src="jqueryslider/images/portfolio_two/13_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/14.jpg"><img src="jqueryslider/images/portfolio_two/14_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/15.jpg"><img src="jqueryslider/images/portfolio_two/15_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/16.jpg"><img src="jqueryslider/images/portfolio_two/16_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/17.jpg"><img src="jqueryslider/images/portfolio_two/17_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/18.jpg"><img src="jqueryslider/images/portfolio_two/18_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/19.jpg"><img src="jqueryslider/images/portfolio_two/19_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/20.jpg"><img src="jqueryslider/images/portfolio_two/20_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/21.jpg"><img src="jqueryslider/images/portfolio_two/21_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/22.jpg"><img src="jqueryslider/images/portfolio_two/22_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
		
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/23.jpg"><img src="jqueryslider/images/portfolio_two/23_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
            <li>
              <a class="thumb" href="jqueryslider/images/portfolio_two/24.jpg"><img src="jqueryslider/images/portfolio_two/24_thumb.jpg" alt="two" /></a>
              <div class="caption">
                <div class="image-title portfolio_two">&quot;&quot;</div>
              </div>
            </li>
			
          </ul>
          <a class="pageLink next" style="visibility: hidden;" href="#" title="Next Page"></a>
        </div>
      </div>
      <div class="content">
        <div class="slideshow-container">
          <div id="loading" class="loader"></div>
          <div id="slideshow" class="slideshow"></div>
          <div id="controls" class="controls portfolio_two"></div>
          <div id="caption" class="caption-container"></div>
        </div>
      </div>
      <!-- end gallery HTML containers -->
    </div>
    <!-- end content -->

  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/jquery.easing-sooper.js"></script>
  <script type="text/javascript" src="js/jquery.sooperfish.js"></script>
  <!-- initialise sooperfish menu -->
  <script type="text/javascript">
    $(document).ready(function() {

      $('ul.sf-menu').sooperfish();

    });
  </script>
  <script type="text/javascript" src="js/jquery.galleriffic.js"></script>
  <script type="text/javascript" src="js/jquery.opacityrollover.js"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      // we only want these styles applied when javascript is enabled
      $('div.content').css('display', 'block');
      // initially set opacity on thumbs and add additional styling for hover effect on thumbs
      var onMouseOutOpacity = 0.67;
      $('#thumbs ul.thumbs li, div.navigation a.pageLink').opacityrollover({
        mouseOutOpacity:   onMouseOutOpacity,
        mouseOverOpacity:  1.0,
        fadeSpeed:         'fast',
        exemptionSelector: '.selected'
      });
      // initialize advanced galleriffic gallery
      var gallery = $('#thumbs').galleriffic({
        delay:                     3500,
        numThumbs:                 10,
        preloadAhead:              10,
        enableTopPager:            false,
        enableBottomPager:         false,
        imageContainerSel:         '#slideshow',
        controlsContainerSel:      '#controls',
        captionContainerSel:       '#caption',
        loadingContainerSel:       '#loading',
        renderSSControls:          true,
        renderNavControls:         true,
        playLinkText:              'Play Slideshow',
        pauseLinkText:             'Pause Slideshow',
        prevLinkText:              '&lsaquo; Previous Photo',
        nextLinkText:              'Next Photo &rsaquo;',
        nextPageLinkText:          'Next &rsaquo;',
        prevPageLinkText:          '&lsaquo; Prev',
        enableHistory:             true,
        autoStart:                 false,
        syncTransitions:           true,
        defaultTransitionDuration: 900,
        onSlideChange:             function(prevIndex, nextIndex) {
          // 'this' refers to the gallery, which is an extension of $('#thumbs')
          this.find('ul.thumbs').children()
            .eq(prevIndex).fadeTo('fast', onMouseOutOpacity).end()
            .eq(nextIndex).fadeTo('fast', 1.0);

          // update the photo index display
          this.$captionContainer.find('div.photo-index')
            .html('Photo '+ (nextIndex+1) +' of '+ this.data.length);
        },
        onPageTransitionOut:       function(callback) {
          this.fadeTo('fast', 0.0, callback);
        },
        onPageTransitionIn:        function() {
          var prevPageLink = this.find('a.prev').css('visibility', 'hidden');
          var nextPageLink = this.find('a.next').css('visibility', 'hidden');
          // show appropriate next / prev page links
          if (this.displayedPage > 0)
            prevPageLink.css('visibility', 'visible');
          var lastPage = this.getNumPages() - 1;
          if (this.displayedPage < lastPage)
            nextPageLink.css('visibility', 'visible');
          this.fadeTo('fast', 1.0);
        }
      });
      // event handlers for custom next / prev page links
      gallery.find('a.prev').click(function(e) {
        gallery.previousPage();
        e.preventDefault();
      });
      gallery.find('a.next').click(function(e) {
        gallery.nextPage();
        e.preventDefault();
      });
    });

                tabdropdown.init("navigation", 0)
                gooeymenu.setup({id:"gooeymenu2", selectitem:-6, fx:"swing"})

  </script>



    
    
    
    
    
    
    
    
    
    
</td>
</tr>
</table>
</td>

</tr>
</table></td>

</tr>
</table>
<br />
<table class="footer">
<tr>
<td align="left">
&nbsp;&nbsp;&nbsp;&nbsp;© 2013 - Marlum Nigeria LTD
</td>
<td>

</td>
<td align="right">
Developer: Libra Information Technology(Gensoft-Software)&nbsp;&nbsp;&nbsp;&nbsp;
</td>
</tr>
</table>

</body>
</html>
