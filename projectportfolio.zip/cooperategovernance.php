<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Marlum Nigeria LTD:</title>
<link href="css/css_plugin.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/ddcolortabs.css"  media="screen" rel="stylesheet" type="text/css"/>
<link href="css/gooeymenu.css"   media="screen" rel="stylesheet" type="text/css"/>

<script type="text/javascript" src="script/jquery-1.9.1.js"></script>
<script type="text/javascript" src="script/dropdowntabs.js"></script>
<script type="text/javascript" src="script/gooeymenu.js"></script>

<!--animation-->

<link type="text/css" href="css/style.css" rel="stylesheet" media="screen" />
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<!--end of anim -->
</head>
<body>
<div align="center">
<table height="20">
<tr>
<td>
</td>
</tr>
</table>
<table width="1000" align="center"  class="bannerwrapper">
<tr>
<td width="15">
</td>
<td style="background-image:url(images/logo.png);
background-position:left;
background-repeat:no-repeat
">
</td>
<td colspan="3">
</td>
</tr>
</table>

<table width="1000" class="wrapper" align="center"  >
<tr >
<td colspan="5">
<div id="navigation">
<ul id="gooeymenu2" class="solidblockmenu">
<li><a href="#" id="register">|&nbsp;&nbsp;&nbsp;HOME&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="#" rel="dropmenu1" id="search">|&nbsp;&nbsp;&nbsp;ABOUT US&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="#" id="update" rel="dropmenu2">|&nbsp;&nbsp;&nbspPROJECT PORTFOLIO&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="#" id="remove"  rel="dropmenu3">|&nbsp;&nbsp;&nbsp;INVESTOR RELATION&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href="#" id="report" rel="dropmenu4">|&nbsp;&nbsp;&nbsp;CAREER&nbsp;&nbsp;&nbsp;|</a></li>
<li><a href=".php" id="logout">|&nbsp;&nbsp;&nbsp;CONTACT US&nbsp;&nbsp;&nbsp;|</a><li>
</ul>
</div>
<div id="dropmenu1" class="dropmenudiv_a">
                 <a href="#" id="male">Our Profile</a>
                    <a href="#" id="female">Our Values</a>
                     <a href="#" id="nd1">Our History</a>
                        <a href="#"  id="nd2">Our Group</a>
                      
      </div>
					<div id="dropmenu2" class="dropmenudiv_a">
                 <a href="#" id="male">Infrastructure</a>
                    <a href="#" id="female">Buildings</a>
                     <a href="#" id="nd1">Industries</a>
                        <a href="#"  id="nd2">Facility Services</a>
                    </div>
<div id="dropmenu3" class="dropmenudiv_a">
                 <a href="#" id="male">Board Of Directors</a>
                    <a href="#" id="female">Corperate Governance</a>
                     <a href="#" id="nd1">Business Principles</a>
                        <a href="#"  id="nd2">Business Development</a>
                          <a href="#" id="ndyr1">Financial Reporting</a>
      </div>
					<div id="dropmenu4" class="dropmenudiv_a">
                 <a href="#" id="male">Corperate Culture</a>
                    <a href="#" id="female">Marlum Experiances</a>
                     <a href="#" id="nd1">Apply Online</a>
                    </div>

   <script>
                tabdropdown.init("navigation", 0)
                gooeymenu.setup({id:"gooeymenu2", selectitem:-6, fx:"swing"})
                </script>  
               
</td>
</tr>
</table>
<table class="pixwrapper" style="" cellpadding="0" cellspacing="0">
<tr>
<!--style="background:url(images/logoback.png);"-->
<td  valign="top" style="
width:960px;
border:1px solid #b52025; ">
aaaaaa
</td>
</tr>
</table>
<table>
<tr>
<td class="contentwrapper">
<table width="100%" cellpadding="0" cellspacing="0" >
<tr>
<td colspan="2" style="height:10px"></td>
</tr>
<tr style="height:35px; ">
<td width="60%" style="color:#999999; font-size:28px; font-style:inherit; font-family:Calibre; font-weight:500; padding-left:20px">Co-Operate Governance</td>
<td width="40%" style="background:url(images/menu.png); padding-left:10px; color:#FFFFFF">|CO-OPERATE GOVERNANCE|</td>
</tr>
<tr style="height:275px;">
<td colspan="2" valign="top"></td>
</tr>
</table></td>

</tr>
</table>
<br />
<table class="footer">
<tr>
<td align="left">
&nbsp;&nbsp;&nbsp;&nbsp;© 2013 - Marlum Nigeria LTD
</td>
<td>

</td>
<td align="right">
Developer: Libra Information Technology(Gensoft-Software)&nbsp;&nbsp;&nbsp;&nbsp;
</td>
</tr>
</table>

</body>
</html>
